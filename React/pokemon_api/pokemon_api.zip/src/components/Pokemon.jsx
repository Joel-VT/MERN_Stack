import React, { useState } from 'react';

const Pokemon = (props) => {
    const [allPokemon, setAllPokemon] = useState([]);

    const callPokemonApi = () => {
        fetch('https://pokeapi.co/api/v2/pokemon/?limit=870')
        .then(response => response.json())
        .then(response => setAllPokemon(response.results))
    };

    return (
        <>
            <button onClick={callPokemonApi}>Fetch Pokemon</button>
            {
                allPokemon.map((pokemon, i) => {
                    return (
                        <p>{i+1}. {pokemon.name}</p>
                    );
                })
            }
        </>
    )
}

export default Pokemon;