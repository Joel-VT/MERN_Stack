import React, { useState } from 'react';

const FormComponent = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password , setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [validFirst, setValidFirst] = useState("");
    const [validLast, setValidLast] = useState("");
    const [validEmail, setValidEmail] = useState("");
    const [validPassword, setValidPassword] = useState("");
    const [validConfirm, setValidConfirm] = useState("");

    const handleFirst = (e) => {
        setFirstName(e.target.value);
        if(firstName.length < 2){
            setValidFirst("First name must be atleast 2 characters");
        } else {
            setValidFirst("");
        }
    }

    const handleLast = (e) => {
        setLastName(e.target.value);
        if(lastName.length < 2){
            setValidLast("Last name must be atleast 2 characters");
        } else {
            setValidLast("");
        }
    }

    const handleEmail = (e) => {
        setEmail(e.target.value);
        if(email.length < 2){
            setValidEmail("Email must be atleast 2 characters");
        } else {
            setValidEmail("");
        }
    }

    const handlePassword = (e) => {
        setPassword(e.target.value);
        if(password.length < 8){
            setValidPassword("Password must be atleast 8 characters");
        } else {
            setValidPassword("");
        }
    }

    const handleConfirm = (e) => {
        setConfirmPassword(e.target.value);
        if(e.target.value != password){
            setValidConfirm("Passwords dont match");
        } else {
            setValidConfirm("");
        }
    }

    return (
        <>
            <form action="">
                <div id='formLabel'>
                    <label htmlFor="firstName">First Name:</label>
                    <input type="text" onChange={ handleFirst } id="firstName"/>
                </div>
                {
                    validFirst ? 
                    <p>{validFirst}</p> :
                    ''
                }
                <div id='formLabel'>
                    <label htmlFor="lastName">Last Name:</label>
                    <input type="text" onChange={ handleLast } id="lastName"/>
                </div>
                {
                    validLast ? 
                    <p>{validLast}</p> :
                    ''
                }
                <div id='formLabel'>
                    <label htmlFor="email">Email:</label>
                    <input type="text" onChange={ handleEmail } id="email"/>
                </div>
                {
                    validEmail ? 
                    <p>{validEmail}</p> :
                    ''
                }
                <div id='formLabel'>
                    <label htmlFor="password">Password:</label>
                    <input type="password" onChange={ handlePassword } id="password"/>
                </div>
                {
                    validPassword ? 
                    <p>{validPassword}</p> :
                    ''
                }
                {
                    validConfirm ? 
                    <p>{validConfirm}</p> :
                    ''
                }
                <div id='formLabel'>
                    <label htmlFor="confirmPassword">Confirm Password:</label>
                    <input type="password" onChange={ handleConfirm } id="Confirm Password"/>
                </div>
            </form>
            <div id='form-content'>
                <p id='text-center'>Your Form Data</p>
                <p>First Name: {firstName}</p>
                <p>Last Name: {lastName}</p>
                <p>Email: {email}</p>
                <p>Password: {password}</p>
                <p>Confirm Password: {confirmPassword}</p>
            </div>
        </>
    );
}

export default FormComponent;