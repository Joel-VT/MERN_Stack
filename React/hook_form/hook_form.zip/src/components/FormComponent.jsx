import React, { useState } from 'react';

const FormComponent = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password , setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    return (
        <>
            <form action="">
                <div id='formLabel'>
                    <label htmlFor="firstName">First Name:</label>
                    <input type="text" onChange={ (e) => setFirstName(e.target.value) } id="firstName"/>
                </div>
                <div id='formLabel'>
                    <label htmlFor="lastName">Last Name:</label>
                    <input type="text" onChange={ (e) => setLastName(e.target.value) } id="lastName"/>
                </div>
                <div id='formLabel'>
                    <label htmlFor="email">Email:</label>
                    <input type="text" onChange={ (e) => setEmail(e.target.value) } id="email"/>
                </div>
                <div id='formLabel'>
                    <label htmlFor="password">Password:</label>
                    <input type="password" onChange={ (e) => setPassword(e.target.value) } id="password"/>
                </div>
                <div id='formLabel'>
                    <label htmlFor="confirmPassword">Confirm Password:</label>
                    <input type="password" onChange={ (e) => setConfirmPassword(e.target.value) } id="Confirm Password"/>
                </div>
            </form>
            <div id='form-content'>
                <p id='text-center'>Your Form Data</p>
                <p>First Name: {firstName}</p>
                <p>Last Name: {lastName}</p>
                <p>Email: {email}</p>
                <p>Password: {password}</p>
                <p>Confirm Password: {confirmPassword}</p>
            </div>
        </>
    );
}

export default FormComponent;