import './App.css';
import './FormComponent.css';
import FormComponent from './components/FormComponent';

function App() {
  return (
    <div className="App">
      <FormComponent />
    </div>
  );
}

export default App;
